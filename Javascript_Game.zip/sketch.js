let startT, deltaT = 3000, doit = false;
var points = 0;
function setup() {
  createCanvas(500, 500);
  startT=millis();
}

let x = 20;
let y = 480;
var level = 0;
var yes = true;
var yes2 = true;
var yes3 = true;
var yes4 = true;
var enter = false;
var enter2 = false;
var level2 = false;
var o1 = true;
var powup = false;
var portgo = false;
var dodo = true;
var savegame = false;
// this program was hard, but not that bad once you understand how it works
//it works by finding out if the ball is on the ground, and calculates how high it can jump
//if the ball is on the ground, it is either on y = max, or on a platform
//the distance the ball can jump is a derivative to what is above it; therefore, it will find out the closest platform on top, and jump that height
//when the ball is not on the ground, the ball is under free fall
//NOTES
//the reason I did not put a if rightarrow or if left arrow in the jump sectin is because that will skip the closest platform section - there is a way to fix this but it takes too much time and effort
//I'm not actually sure why you may have to jump to activate a bonus star, or keyget function - I'm guessing it's because the move function is before the keygets, and stuff, but that would contradict how the spike function works even after move()
function draw() {
  if (level == 0){
    background(220);
    text("Press ENTER to play this game", 200, 250);
    text("double your jump with a powerp, springs double your jump, don't hit the spikes or laser", 0, 300);
    text("portals take you somewhere else, get the key to open the door, down arrow saves you if you have saver", 50, 340);
  }


  
  if (keyIsDown(ENTER)){
      level = 1;
      }

  if (level == 1){
      frameRate(30) //the ball's kind of fast
      background(255, 150, 67);
      var l1p = level1_platforms();
      var g = isground(x, y, l1p, 470);
      var p = spring(x, y);
      ellipseMode(CENTER);
      fill(255, 255, 0);
      ellipse(x, y, 20, 20);
      var a = move(g, l1p, 500, 480, 10, p, false, [false], [false], [false]);
      var g2 = isground(x, y, l1p, 470)
      if (g == false){
        y += 5; // if not on ground, must be in air, therefore fall
      }
      var s = spike(x, y)
      if (s == true){
        lose()
        windows.close();
        
      }
    var k = keyget(x, y, yes2);
    if (k == true && yes2 == true){
      points += 5;
      yes2 = false;
      enter = true;
    }
    //print(enter);
    var d = door(x, y);
    if (d == true && enter == true){ //the enter indicates that the key has been retrieved
      points += 50;
      x = 50;
      y = 950;
      level = 2;
    }
    var ss = starget(x, y, yes); //it sucks how their's no hide function in p5
    if (ss == true && yes == true){
      points += 5;
      yes = false;
    }

    if (doit == true) { // I tried here and uh .. trying usually doesn't work
        fill(255,0,0);
      var l = laser(x, y);


      if (l == true){
        lose()
        windows.close()
        
      }
      doit = false;
      
      
      }
      myTimer(); // I didn't know how to initiate two or three timers and that really screwed me
    

    
    text(points, 450, 50, 50, 50);
    
    
    


  }
  if (level == 2){
    x = 40;
    y = 980;
    level += 1;
  }
  if (level == 4){
    x = 400;
    y = 980;
    level += 1;
    yes4 = true;
    o1 = true;
    enter2 = true;
    yes2 = true;
  }
  if(level == 3){
    createCanvas(500, 1000);
    background(255, 150, 67);
    var l1p2 = level2_platforms();
    var pp = powerup1(x, y, o1);
    if (pp == true && o1 == true){
      o1 = false;
      powup = true;
    }
    //print(powup)
    var g3 = isground(x, y, l1p2, 970);
    ellipseMode(CENTER);
    fill(255, 255, 0);
    ellipse(x, y, 20, 20);
    var port = portal(x, y);
    var a2 = move(g3, l1p2, 1000, 480, 10, false, powup, port, [false], [false]);
    var g4 = isground(x, y, l1p2, 970)
    if (g4 == false){
      y += 5;
    }
    //print(g4);
    var s2 = spike(x, y)
    if (s2 == true){
      lose()
      windows.close();
        
    }
    var k2 = keyget2(x, y, yes4);
    if (k2 == true && yes4 == true){
      points += 5;
      yes4 = false;
      enter2 = true;
    }
    
    //print(enter);
    var d2 = door2(x, y);
    if (d2 == true && enter2 == true){
      points += 50;
      x = 50;
      y = 950;
      level = 4;
    }
    var ss2 = starget2(x, y, yes2);
    if (ss2 == true && yes2 == true){
      points += 5;
      yes2 = false;
    }


    if (doit == true) {
        fill(255,0,0);
      var l2 = laser2(x, y);


      if (l2 == true){
        lose()
        windows.close()
        
      }
      doit = false;
      
      
      }
      myTimer();
    

    
    text(points, 450, 50, 50, 50);
  }
  if (level == 5){
    createCanvas(500, 1000);
    background(255, 150, 67);
    var l1p3 = level3_platforms();
    var pp2 = powerup2(x, y, o1);
    if (dodo){
      var sav = saver(x, y);
      if (sav == true){
        savegame = true;
        dodo = false;
      }
    }
    
    if (savegame == true && keyIsDown(DOWN_ARROW)){
      x = 100;
      y = 970;
      
    }
    if (pp2 == true && o1 == true){
      o1 = false;
      powup = true;
    }
    //print(powup)
    var g5 = isground(x, y, l1p3, 970);
    ellipseMode(CENTER);
    fill(255, 255, 0);
    ellipse(x, y, 20, 20);
    var port2 = portal(x, y);
    var port3 = portal2(x, y);
    var port4 = portal4(x, y);
    var a3 = move(g5, l1p3, 1000, 480, 10, false, powup, port2, port3, port4);
    var g6 = isground(x, y, l1p3, 970)
    if (g5 == false){
      y += 5;
    }
    //print(g4);
    var s3 = spike3(x, y)
    if (s3 == true){
      lose()
      windows.close();
        
    }
    var k3 = keyget3(x, y, yes4);
    if (k3 == true && yes4 == true){
      points += 5;
      yes4 = false;
      enter2 = true;
    }
    
    //print(enter);
    var d3 = door2(x, y);
    if (d3 == true && enter2 == true){
      points += 50;
      x = 50;
      y = 950;
      level = 6;
    }
    var ss3 = starget3(x, y, yes2);
    if (ss3 == true && yes2 == true){
      points += 5;
      yes2 = false;
    }


    if (doit == true) {
        fill(255,0,0);
      var l3 = laser2(x, y);


      if (l3 == true){
        lose()
        windows.close()
        
      }
      doit = false;
      
      
      }
      myTimer();
    

    
    text(points, 450, 50, 50, 50);
  }
  if(level == 6){
    createCanvas(500, 500);
    background(0, 255, 0);
    text("you win", 230, 250, 50, 50);
    text(points, 230, 230, 50, 50);
  }

}
function isground(x, y, array, gate){
  var ground = false;
  for (let i = 0; i < array.length; i++){
    var t = touchplatform(x, y, array[i][0], array[i][1], array[i][2], array[i][3])
    if (t == true){
      ground = true;
    }
  }
  if (y > gate){
    ground = true
  }
  return ground;
}
// is ground consists of is x > canvas_max or gate, and touchplatform of all the platform locations, which are stored in "array"

//the move function sucks in p5 - there's no other word for it, it just sucks that much
function move(ground, array, gateup, gateside, gateside2, p, power, port, port2, port3){
  var direction;
  if (keyIsDown(LEFT_ARROW)) {
    if (x > 0 && x < 500){
      x -= 5;
      direction = 1;
    }
  }

  if (keyIsDown(RIGHT_ARROW)) {
    if (x > 0 && x < 500){
      x += 5;
      direction = 2;
    }
    
  }
  if (port[0] == true){
    x = port[1];
    y = port[2];
  }
  if (port2[0] == true){
    x = port2[1];
    y = port2[2];
  }
  if (port3[0] == true){
    x = port3[1];
    y = port3[2];
  }
  //port means portal, so if x and y are located in a portal, the x and y will change to where the portal brings you
  
  //this part took a lot of time - basically, it uses a second max and max function ish - the hard part was when I included power jumps and portals - those kileld this part quite literally
  var difference = 100;
  var smallest = 100;
  var plus = 100;
  if (power == true){
    difference = 200;
    smallest = 200;
    plus = 200;
  }
  var count = 0;
  for (let i = 0; i < array.length; i++){
      var c = closestplat(x, y, array[i][0], array[i][1], array[i][2], array[i][3], plus)
      //this is the part I was referring to, findin g the closest platform, if you want to see this in action, undoubleslash the (print(smalles)) underneath
      if (c == true){
        count += 1;
        difference = y - array[i][1];
        if (difference < smallest && difference > 0){
          smallest = difference;
        }
        
      }
  }
  //print(smallest)
  var d = smallest/10
  if (count == 0 && smallest == 100){
    d = 10;
  }
  if (p == true){ //spring
    d = 20;
  }

  //print(d);
  if (keyIsDown(UP_ARROW) && ground == true) {
    if (y > 0 && y < gateup){
      for (let i = 0; i < 10; i ++){
          y -= d;
          

      }
    }
  } 
  
  if (x > gateside){
    x -= 10;
  }
  if (x < gateside2){
    x += 10;
  }
  //if you are almost at the edges of the screen, then this will undo that

  
}
function level1_platforms(){ //platforms are pretty straightforward
  var platlist = [];
  var savethis = [];
  fill(0, 255, 0)
  rectMode(CENTER);
  rect(100, 450, 300, 20);
  savethis = [100, 450, 300, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(300, 400, 300, 20);
  savethis = [300, 400, 300, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(50, 340, 200, 20);
  savethis = [50, 340, 200, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(150, 300, 100, 20);
  savethis = [150, 300, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(300, 300, 100, 20);
  savethis = [300, 300, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(450, 250, 150, 20);
  savethis = [450, 250, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(450, 250, 150, 20);
  savethis = [450, 250, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(250, 150, 150, 20);
  savethis = [250, 150, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(60, 120, 150, 20);
  savethis = [60, 120, 150, 20];
  platlist.push(savethis);
  
  return platlist;
}

function level2_platforms(){
  var platlist = [];
  var savethis = [];
  fill(0, 255, 0)
  rectMode(CENTER);
  rect(100, 950, 300, 20);
  savethis = [100, 950, 300, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(400, 880, 250, 20);
  savethis = [400, 880, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 800, 250, 20);
  savethis = [100, 800, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 800, 250, 20);
  savethis = [100, 800, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(10, 540, 100, 20);
  savethis = [10, 540, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 680, 100, 20);
  savethis = [100, 680, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(300, 500, 150, 20);
  savethis = [300, 500, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 350, 150, 20);
  savethis = [100, 350, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(250, 220, 150, 20);
  savethis = [250, 220, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(50, 120, 150, 20);
  savethis = [50, 120, 150, 20];
  platlist.push(savethis);
  
  return platlist;
}


function level3_platforms(){
  var platlist = [];
  var savethis = [];
  fill(0, 255, 0)
  rectMode(CENTER);
  rect(400, 950, 300, 20);
  savethis = [400, 950, 300, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 880, 250, 20);
  savethis = [100, 880, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(400, 700, 250, 20);
  savethis = [400, 700, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 800, 250, 20);
  savethis = [100, 800, 250, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(10, 540, 100, 20);
  savethis = [10, 540, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 680, 100, 20);
  savethis = [100, 680, 100, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(300, 500, 150, 20);
  savethis = [300, 500, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(100, 350, 150, 20);
  savethis = [100, 350, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(250, 220, 150, 20);
  savethis = [250, 220, 150, 20];
  platlist.push(savethis);
  
  rectMode(CENTER);
  rect(50, 120, 150, 20);
  savethis = [50, 120, 150, 20];
  platlist.push(savethis);
  
  return platlist;
}


let img;
let img2;
let img3;
let img4;
function preload() {
  img = loadImage('key.png');
  img2 = loadImage('star.png');
  img3 = loadImage('p.jpeg');
  img4 = loadImage('portal.jpeg');
}
// every collision detection follows the same pattern, grab the ball's x and y, compare them to the objects x and y, and change the "return" accordingly (so true or false)
function portal(x, y){
  var port = false;

    image(img4, 460, 860, 20, 20);
    
    if (x > 430 && x < 490 && y > 800 && y < 890){
      port = true;

    }
  newx = 60;
  newy = 300;
  var portlist = [port, newx, newy]
  return portlist;
}

function portal4(x, y){
  var port = false;

    image(img4, 400, 860, 20, 20);
    
    if (x > 390 && x < 410 && y > 800 && y < 900){
      port = true;

    }
  newx = 280;
  newy = 720;
  var portlist = [port, newx, newy]
  return portlist;
}
function saver(x, y){ //saves the game in level 3, press down arrow to use
  var save = false;
    fill (0, 0, 255);
    rect(100, 640, 20, 20);
    
    if (x > 90 && x < 110 && y > 630 && y < 650){
      save = true;

    }

  return save;
}
function portal2(x, y){
  var port = false;

    image(img4, 60, 840, 20, 20);
    
    if (x > 40 && x < 80 && y > 810 && y < 860){
      port = true;

    }
  newx = 40;
  newy = 960;
  var portlist = [port, newx, newy]
  return portlist;
}

function starget(x, y, once){
  var star = false;
  if (once == true){
      image(img2, 460, 270, 20, 20);
    
    if (x > 445 && x < 475 && y > 260 && y < 280){
      star = true;

    }
    
  }
  return star;
}

function starget2(x, y, once){
  var star = false;
  if (once == true){
      image(img2, 40, 270, 20, 20);
    
    if (x > 30 && x < 50 && y > 260 && y < 280){
      star = true;

    }
    
  }
  return star;
}
function starget3(x, y, once){
  var star = false;
  if (once == true){
      image(img2, 400, 270, 20, 20);
    
    if (x > 260 && x < 280 && y > 390 && y < 410){
      star = true;

    }
    
  }
  return star;
}

function powerup1(x, y, once){ //allows double the jump height
  var power = false;
  if (once == true){
      image(img3, 40, 965, 20, 20);
    
    if (x > 30 && x < 50 && y > 960 && y < 980){
      power = true;

    }
    
  }
  return power;
}

function powerup2(x, y, once){
  var power = false;
  if (once == true){
      image(img3, 300, 965, 20, 20);
    
    if (x > 290 && x < 310 && y > 960 && y < 980){
      power = true;

    }
    
  }
  return power;
}



function spring(x, y){
  var powerjump = false;
  fill(255);
  ellipse(400, 250, 5, 5);
  if (x > 390 && x < 410 && y > 240 && y < 260){
    powerjump = true;
    
  }
  ellipse(460, 475, 5, 5);
  if (x > 450 && x < 470 && y > 465 && y < 485){
    powerjump = true;
    
  }
  return powerjump;
    
  
}

function spring3(x, y){
  var powerjump = false;
  fill(255);
  ellipse(50, 640, 5, 5);
  if (x > 45 && x < 65 && y > 630 && y < 650){
    powerjump = true;
    
  }
  ellipse(225, 500, 5, 5);
  if (x > 220 && x < 230 && y > 490 && y < 510){
    powerjump = true;
    
  }
  ellipse(25, 350, 5, 5);
  if (x > 20 && x < 30 && y > 340 && y < 360){
    powerjump = true;
    
  }
  ellipse(175, 200, 5, 5);
  if (x > 170 && x < 180 && y > 190 && y < 210){
    powerjump = true;
    
  }
  return powerjump;
    
  
}


function spike(x, y){ //makes you lose
  var spiker = false;
  fill(255, 0, 0);
  triangle(220, 140, 250, 140, 235, 130);
  if (x > 220 && x < 250 && y > 120 && y < 150){
    spiker = true;
    
  }
  
  triangle(280, 400, 320, 400, 300, 380);
  if (x > 280 && x < 320 && y > 380 && y < 400){
    spiker = true;
    
  }
  return spiker;
}

function spike3(x, y){
  var spiker = false;
  fill(255, 0, 0);
  triangle(220, 140, 250, 140, 235, 130);
  if (x > 220 && x < 250 && y > 120 && y < 150){
    spiker = true;
    
  }
  
  triangle(280, 400, 320, 400, 300, 380);
  if (x > 280 && x < 320 && y > 380 && y < 400){
    spiker = true;
    
  }
  
  triangle(270, 800, 290, 800, 280, 780);
  if (x > 270 && x < 290 && y > 780 && y < 800){
    spiker = true;
    
  }
  triangle(50, 960, 50, 940, 70, 950);
  if (x > 50 && x < 70 && y > 940 && y < 960){
    spiker = true;
    
  }
    triangle(50, 990, 50, 970, 70, 980);
  if (x > 50 && x < 70 && y > 960 && y < 980){
    spiker = true;
    
  }
    triangle(50, 930, 50, 910, 70, 920);
  if (x > 50 && x < 70 && y > 910 && y < 930){
    spiker = true;
    
  }
    triangle(100, 300, 120, 300, 110, 280);
  if (x > 100 && x < 120 && y > 280 && y < 300){
    spiker = true;
    
  }
  triangle(340, 490, 380, 490, 360, 470);
  if (x > 340 && x < 380 && y > 470 && y < 490){
    spiker = true;
    
  }
  triangle(370, 700, 410, 700, 390, 680);
  if (x > 370 && x < 410 && y > 680 && y < 700){
    spiker = true;
    
  }
  triangle(400, 700, 440, 700, 420, 680);
  if (x > 400 && x < 440 && y > 680 && y < 700){
    spiker = true;
    
  }
  return spiker;
}

function keyget(x, y, once){ //you need a key to open a door
  var key = false;
  if (once == true){
      image(img, 340, 380, 20, 20);
    if (x > 320 && x < 360 && y > 360 && y < 400){
      key = true;
    
    }
  }
  
  return key;
}

function keyget2(x, y, once){
  var key = false;
  if (once == true){
      image(img, 340, 380, 20, 20);
    if (x > 320 && x < 360 && y > 360 && y < 400){
      key = true;
    
    }
  }
  
  return key;
}


function keyget3(x, y, once){
  var key = false;
  if (once == true){
      image(img, 30, 970, 20, 20);
    if (x > 20 && x < 40 && y > 960 && y < 980){
      key = true;
    
    }
  }
  
  return key;
}
function myTimer() { //timer function is nice
  if (millis() > startT + deltaT) {
    startT = millis()
    //console.log("it is time for it now"); // do what you have to do!
    doit = true;
               // repeats second circle as loop
  }
}
function lose(){
  background(255, 0, 0);
  fill(0, 0, 0);
  text("you lose", 230, 250, 50, 50);
}


function laser (x, y){ // I tried, and it didn't go to my expectations
  var las = false
  fill(255, 0, 0);
  rect(250, 350, 500, 5);
  if (y > 340 && y < 360){
    las = true;
    
  }
  return las;
}
function laser2 (x, y){
  var las = false
  fill(255, 0, 0);
  rect(250, 350, 500, 5);
  if (y > 340 && y < 360){
    las = true;
    
  }
  rect(250, 700, 500, 5);
  if (y > 690 && y < 710){
    las = true;
    
  }
  return las;
}

function door(x, y){ //how you get to the next level
  fill(41, 19, 19);
  rect(20, 80, 40, 60);
  fill(100, 100, 100);
  rect (20, 70, 20, 40);
  var dooris = false;
  if (x > 0 && x < 40 && y > 40 && y < 140){
    dooris = true;
    
  }
  return dooris;
}

function door2(x, y){
  fill(41, 19, 19);
  rect(20, 80, 40, 60);
  fill(100, 100, 100);
  rect (20, 70, 20, 40);
  var dooris = false;
  if (x > 0 && x < 40 && y > 40 && y < 140){
    dooris = true;
    
  }
  return dooris;
}

function bottomplat(x, y, x2, y2, w, h){
  var bottom = false;
  if (x > x2 - w/2 && x < x2 + w/2 && y > y2 && y < y2 + h/2){
    bottom = true;
    
  }
  return bottom;
}

function closestplat(x, y, x2, y2, w, h, plus){
  var close = false;
  if (x > x2 - w/2 && x < x2 + w/2 && y - plus < y2){
    close = true;
    
  }
  return close;
}




function touchplatform(x, y, x2, y2, w, h){
  var touch = false;
  if (x > x2 - w/2 && x < x2 + w/2 && y < y2 && y > y2 - h/2){
    touch = true;

    }
  return touch;
}